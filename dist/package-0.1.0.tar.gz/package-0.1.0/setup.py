from setuptools import setup, find_packages

setup(
    name="package",
    version="0.1.0",
    description="housing data package",
    long_description="A python package for housing data code",
    author="Anant Chandak",
    packages=find_packages(),
)
